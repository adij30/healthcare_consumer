class Address:
    def __init__(self, city, state, pincode, id=0):
        self.city = city
        self.state = state
        self.pin_code = pincode
        self.id = id


class Doctor:
    def __init__(self, name, speciality, experience, salary, email, blog, hospital_id, id=0):
        self.name = name
        self.speciality = speciality
        self.experience = experience
        self.salary = salary
        self.email = email
        self.blog = blog
        self.hospital = hospital_id
        self.id = id


class Hospital:
    def __init__(self, name, phone_no, address_id, id=0):
        self.name = name
        self.phone_no = phone_no
        self.address = address_id
        self.id = id


class Patient:
    def __init__(self, name, gender, birth_date, blood_group, diseases, address_id, doctor_id, id=0):
        self.name = name
        self.gender = gender
        self.birth_date = birth_date
        self.blood_group = blood_group
        self.diseases = diseases
        self.address = address_id
        self.doctors = doctor_id
        self.id = id


class Temp:
    def __init__(self, id, name):
        self.id = id
        self.name = name

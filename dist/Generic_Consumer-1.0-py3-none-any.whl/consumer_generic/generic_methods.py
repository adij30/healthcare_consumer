import requests

entity_list = ['address', 'hospital', 'doctor', 'patient']


def get_base_uri(entity=None):
    BASE_URI = f'http://127.0.0.1:8000/api/healthcare/{entity}/'
    return BASE_URI


# print(get_base_uri(entity=entity_list[0]))
# print(get_base_uri(entity=entity_list[1]))
# print(get_base_uri(entity=entity_list[2]))
# print(get_base_uri(entity=entity_list[3]))


def get_all_entities(entity=None):
    if entity in entity_list:
        response = requests.get(get_base_uri(entity))
        print(response.json())
        return response.json()
    else:
        msg = f'''Enter wrong entity...
        Entity must be from {entity_list}'''
        return msg


def get_single_entity(entity=None, entity_id=None):
    if entity in entity_list and type(entity_id) == int:
        print(get_base_uri(entity) + str(entity_id))
        response = requests.get(get_base_uri(entity) + str(entity_id))
        print(response.json())
        return response.json()
    else:
        msg = 'You entered wrong parameters...'
        return msg


def save_entity(entity_object):
    entity_type = entity_object.__class__.__name__
    if entity_type.lower() in entity_list:
        print("Type of entity : ", entity_type)
        response = requests.post(get_base_uri(entity_type.lower()), json=entity_object.__dict__)
        print(response.json())
        return response.json()
    else:
        msg = f'''You pass the '{entity_type}' type of object...
        It must be one of the type from {entity_list}'''
        return msg


def update_entity(entity_object):
    entity_id = entity_object.id
    entity_type = entity_object.__class__.__name__
    if entity_type.lower() in entity_list:
        print("Type of entity : ", entity_type)
        response = requests.put(get_base_uri(entity_type.lower()) + str(entity_id) + '/', json=entity_object.__dict__)
        print(response.json())
        return response.json()
    else:
        msg = f'''You pass the '{entity_type}' type of object...
        It must be one of the type from {entity_list}'''
        return msg


def delete_entity(entity_type=None,entity_id=None):
    if entity_type in entity_list and type(entity_id) == int:
        print(entity_type, entity_id)
        response = requests.delete(get_base_uri(entity_type) + str(entity_id))
        if response.status_code == 404:
            print(response.json())
            return response.json()
        elif response.status_code == 204:
            msg = f'{entity_type.title()} with id {entity_id} Deleted Successfully...'
            return msg
    else:
        msg = 'You entered wrong parameters...'
        return msg



### this is for testing purpose ###

#####get all methods#####
# get_all_entities(enitity_list[2])


######get single methods#####
# get_single_entity(enitity_list[3], 2)


#####save method#####
# ad1 = Address(city='aaa', state='sss', pincode=123321)
# save_entity(ad1)

# d1 = Doctor(name='zzz', speciality='zzz', experience=5, salary=300000, email='zz@clc.in',
#             blog='zz', hospital_id=1)
# save_entity(d1)

# t1 = Temp(id = 5, name='Kunal')
# save_entity(t1)

# h1 = Hospital(name='zzz', phone_no=776222222, address_id=13)
# save_entity(h1)

# p1 = Patient(name='xxxx', gender='Male', birth_date='1985-08-20', blood_group='B+', diseases='zzzzz', address_id=14, doctor_id=[7])
# save_entity(p1)


#####update method#####
# ad1 = Address(id=13, city='qqqq', state='sss', pincode=123321)
# update_entity(ad1)

# d1 = Doctor(id=5, name='vvvvv', speciality='zzz', experience=5, salary=300000, email='zz@clc.in',
#             blog='zz', hospital_id=1)
# update_entity(d1)

# t1 = Temp(id = 5, name='Kunal')
# update_entity(t1)

# h1 = Hospital(id=4, name='cccc', phone_no=776222222, address_id=13)
# update_entity(h1)

# p1 = Patient(id=5, name='zzzz', gender='Female', birth_date='1985-08-20', blood_group='B+', diseases='zzzzz', address_id=13, doctor_id=[5])
# update_entity(p1)


#####delete method#####
# delete_entity(entity_type='hospital', entity_id=7)
# delete_entity(entity_type='address', entity_id=13)
# delete_entity(entity_type='patient', entity_id=6)
# delete_entity(entity_type='doctor', entity_id=7)
